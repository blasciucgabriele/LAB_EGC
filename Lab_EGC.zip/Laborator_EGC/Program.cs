﻿namespace Laborator_EGC
{
    class Program
    {

        static void Main(string[] args)
        {
            Window3D ex = new Window3D();
            ex.Run(30.0, 0.0);
        }
    }
}
