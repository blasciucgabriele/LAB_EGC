﻿using System;
using OpenTK;
using OpenTK.Graphics.OpenGL;
using System.Drawing;
using System.IO;

namespace Laborator_EGC
{
    class Cube3D
    {
        bool gravity = false;
        private float yOffset = 0;
        private float xOffset = 0;
        private float zOffset = 0;
        private int OFFSET = 1;
        Vector3[] fromFile = new Vector3[24];
        int alpha = 255;
        private bool myVisibility;
        private Color myColor;
        int[] rgb = new int[3];
        private Randomizer localR;

        public Cube3D(int x)
        {
            localR = new Randomizer();
            myColor = localR.RandomColor();
            myVisibility = true;
            File_Init_Color();
        }
        public Cube3D()
        {
            LoadFile();
            localR = new Randomizer();
            myColor = localR.RandomColor();
            myVisibility = true;
            Draw();
        }

        public void Draw()
        {
            if (yOffset > 100)
                gravity = true;
            if (gravity)
                yOffset -= 1;
            if (yOffset <= 10) // latura cubului este 10 ( nu trece peste grid)
                gravity = false;

            GL.Begin(PrimitiveType.Quads);
            GL.Color4(myColor);
            for (int i = 0; i < fromFile.Length; i++)
            {
                GL.Vertex3(fromFile[i].X + xOffset, fromFile[i].Y + yOffset, fromFile[i].Z + zOffset);
            }
            GL.End();
        }
        public void File_Init_Color() //LABORATOR 3 SI 4
        {
            using (StreamReader Fisier = new StreamReader("C:\\Users\\blasc\\Desktop\\Full_obj_deployment_OpenTK\\Color.txt"))
            {
                string linie;

                while ((linie = Fisier.ReadLine()) != null)
                {
                    if (linie != null)
                    {
                        string[] s = linie.Split(' ');
                        rgb[0] = Convert.ToInt32(s[0]);
                        rgb[1] = Convert.ToInt32(s[1]);
                        rgb[2] = Convert.ToInt32(s[2]);
                    }
                }
                myColor = Color.FromArgb(alpha, rgb[0], rgb[1], rgb[2]);
            }
        }

        public void Move_y(float val)
        {
            yOffset += val;
        }
        public void Move_x(float val)
        {
            xOffset += val;
        }
        public void Move_z(float val)
        {
            zOffset += val;
        }
        
        public void Gravity()
        {
            gravity = true;
            yOffset = 80;
        }
        public void Show()
        {
            myVisibility = true;
        }

        public void Hide()
        {
            myVisibility = false;
        }

        public void ToggleVisibility()
        {
            myVisibility = !myVisibility;
        }

        public void DiscoMode()
        {
            myColor = localR.RandomColor();
        }

        public void LoadFile()
        {
            using (var sr = new StreamReader("C:\\Users\\blasc\\Desktop\\Full_obj_deployment_OpenTK\\coord_cube.txt"))
            {
                string line; int i = 0;
                while ((line = sr.ReadLine()) != null)
                {
                    string[] splitLine = line.Split(' ');
                    fromFile[i].X = Convert.ToInt32(splitLine[0]);
                    fromFile[i].Y = Convert.ToInt32(splitLine[1]);
                    fromFile[i].Z = Convert.ToInt32(splitLine[2]);
                    i++;
                }
            }
        }
        private int[,] objVertices = {
            {5, 10, 5, 10, 5, 10, 5, 10, 5,10, 5, 10,5, 5, 5,5, 5, 5,5, 10, 5,10, 10, 5,10, 10, 10,10, 10, 10,5, 10, 5,10, 10, 5},
            {5, 5, 12,5, 12, 12,5, 5, 5,5, 5, 5,5, 12, 5,12, 5, 12,12, 12, 12,12, 12, 12,5, 12, 5,12, 5, 12,5, 5, 12,5, 12, 12},
            {6, 6, 6,6, 6, 6,6, 6, 12,6, 12, 12,6, 6, 12,6, 12, 12,6, 6, 12,6, 12, 12,6, 6, 12,6, 12, 12,12, 12, 12,12, 12, 12 }};
        public int[,] citire_fisier_cub_triunghiuri()
        {
            int[,] vct = new int[36, 3];
            string fisier = "C:\\Users\\blasc\\Desktop\\Full_obj_deployment_OpenTK\\cube.txt";

            try
            {
                using (StreamReader s = new StreamReader(fisier))
                {
                    string line;
                    int i = 0;
                    while ((line = s.ReadLine()) != null)
                    {
                        string[] st = line.Split(' ');
                        for (int j = 0; j < 3; j++)
                        {
                            vct[i, j] = Int32.Parse(st[j]);
                        }
                        i++;
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            return vct;
        }
        public void Draw_From_File()
        {
            objVertices = citire_fisier_cub_triunghiuri();
            if (myVisibility)
            {
                GL.Begin(PrimitiveType.Triangles);
                GL.Color4(myColor);
                for (int i = 0; i < 35; i += 3)
                {
                    GL.Vertex3(objVertices[i, 0], objVertices[i, 1], objVertices[i, 2]);
                    GL.Vertex3(objVertices[i + 1, 0], objVertices[i + 1, 1], objVertices[i + 1, 2]);
                    GL.Vertex3(objVertices[i + 2, 0], objVertices[i + 2, 1], objVertices[i + 2, 2]);
                }
                GL.End();
            }
        }

        public void Draw_cub_triunghiuri()
        {
            if (myVisibility)
            {
                GL.Begin(PrimitiveType.Triangles);
                GL.Color4(myColor);
                for (int i = 0; i < 35; i = i + 3)
                {

                    GL.Vertex3(objVertices[0, i], objVertices[1, i], objVertices[2, i]);
                    GL.Vertex3(objVertices[0, i + 1], objVertices[1, i + 1], objVertices[2, i + 1]);
                    GL.Vertex3(objVertices[0, i + 2], objVertices[1, i + 2], objVertices[2, i + 2]);
                }

                GL.End();
            }
        }
        public void ManualMoveMe(bool _relativeForward, bool _relativeBackward, bool _relativeLeft, bool _relativeRight, bool _relativeUp, bool _relativeDown)
        {
            for (int i = 0; i < 35; i = i + 3)
            {

                GL.Vertex3(objVertices[0, i], objVertices[1, i], objVertices[2, i]);
                GL.Vertex3(objVertices[0, i + 1], objVertices[1, i + 1], objVertices[2, i + 1]);
                GL.Vertex3(objVertices[0, i + 2], objVertices[1, i + 2], objVertices[2, i + 2]);

                if (_relativeForward == true)
                {
                    objVertices[2, i] -= OFFSET;
                    objVertices[2, i + 1] -= OFFSET;
                    objVertices[2, i + 2] -= OFFSET;
                }

                if (_relativeBackward == true)
                {
                    objVertices[2, i] += OFFSET;
                    objVertices[2, i + 1] += OFFSET;
                    objVertices[2, i + 2] += OFFSET;
                }

                if (_relativeLeft == true)
                {
                    objVertices[0, i] -= OFFSET;
                    objVertices[0, i + 1] -= OFFSET;
                    objVertices[0, i + 2] -= OFFSET;
                }

                if (_relativeRight == true)
                {
                    objVertices[0, i] += OFFSET;
                    objVertices[0, i + 1] += OFFSET;
                    objVertices[0, i + 2] += OFFSET;
                }

                if (_relativeUp == true)
                {
                    objVertices[1, i] += OFFSET;
                    objVertices[1, i + 1] += OFFSET;
                    objVertices[1, i + 2] += OFFSET;
                }

                if (_relativeDown == true)
                {
                    objVertices[1, i] -= OFFSET;
                    objVertices[1, i + 1] -= OFFSET;
                    objVertices[1, i + 2] -= OFFSET;
                }
            }
        }
        public void schimba_culoare_from_file(int k)
        {
            if (k < 0)
            {
                alpha -= 5;
            }
            else
            {
                alpha += 5;
            }

            if (alpha <= 0)
            {
                alpha = 0;
            }
            if (alpha >= 255)
            {
                alpha = 255;
            }

            myColor = Color.FromArgb(alpha, rgb[0], rgb[1], rgb[2]);
            GL.BlendFunc(BlendingFactor.SrcAlpha, BlendingFactor.OneMinusSrcAlpha);
            Draw_From_File();
            Console.WriteLine(alpha);
        }
        public void schimba_culoare(int k)
        {
            if (k < 0)
            {
                alpha -= 5;
            }
            else
            {
                alpha += 5;
            }

            if (alpha <= 0)
            {
                alpha = 0;
            }
            if (alpha >= 255)
            {
                alpha = 255;
            }

            myColor = Color.FromArgb(alpha, rgb[0], rgb[1], rgb[2]);
            GL.BlendFunc(BlendingFactor.SrcAlpha, BlendingFactor.OneMinusSrcAlpha);
            Draw();
            Console.WriteLine(alpha);
        }

    }
}

 
        
      
        
        
        
       
        
        
       