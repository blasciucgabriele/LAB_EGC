﻿using OpenTK;
using OpenTK.Graphics.OpenGL;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;

namespace Laborator_EGC
{
    /// <summary>
    /// This class manages an 3D line rendered via OpenGL. Fully (well, almost) parametrised.
    /// </summary>
    class Line3D
    {
        private Vector3 pointA;
        private Vector3 pointB;
        private bool myVisibility;
        private float myWidth;
        private Color myColor;
        private Randomizer localR;

        private const float BIG_SIZE = 5.0f;
        private const float DEFAULT_SIZE = 1.0f;

        /// <summary>
        /// Constructor for the LINE3D class. Sets the reasonable defaults for the line attributes.
        /// </summary>
        /// <param name="_r">handler from <see cref="Randomizer()"/>; required for various physical attributes of the object (location, myColor...);</param>
        public Line3D(Randomizer _r)
        {
            localR = _r;

            pointA = localR.Random3DPoint();
            pointB = localR.Random3DPoint();
            myVisibility = true;
            myWidth = DEFAULT_SIZE;
            myColor = _r.RandomColor();
        }

        public Line3D(Vector3 A, Vector3 B)
        {
            localR = new Randomizer();
            pointA = A;
            pointB = B;
            myColor = localR.RandomColor();
            myVisibility = true;
            myWidth = DEFAULT_SIZE;
        }

        public static List<Line3D> citire_fisier()
        {
            List<Line3D> linii = new List<Line3D>();
            Vector3[] vect;
            string fisier = "C:\\Users\\blasc\\Desktop\\Full_obj_deployment_OpenTK\\Coordinates.txt";
            try
            {
                using (StreamReader s = new StreamReader(fisier))
                {
                    string line;

                    while ((line = s.ReadLine()) != null)
                    {
                        string[] st = line.Split(' ');
                        vect = new Vector3[st.Length];
                        for (int i = 0; i < st.Length; i++)
                        {
                            string[] pt = st[i].Split(',');
                            Vector3 pnt = new Vector3(Int32.Parse(pt[0]), Int32.Parse(pt[1]), Int32.Parse(pt[2]));
                            vect[i] = pnt;
                        }
                        if (st.Length == 2)
                        {
                            Line3D tr = new Line3D(vect[0], vect[1]);
                            linii.Add(tr);
                        }
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            return linii;
        }
        /// <summary>
        /// This methods handles the drawing of the object. Must be called - always - from OnRenderFrame() method! The drawing can be unconditional.
        /// </summary>
        public void Draw()
        {
            if (myVisibility)
            {
                GL.LineWidth(myWidth);
                GL.Begin(PrimitiveType.Lines);
                GL.Color3(myColor);
                GL.Vertex3(pointA);
                GL.Vertex3(pointB);
                GL.End();
            }
        }

        /// <summary>
        /// Sets visibility of the object ON.
        /// </summary>
        public void Show()
        {
            myVisibility = true;
        }

        /// <summary>
        /// Sets visibility of the object OFF.
        /// </summary>
        public void Hide()
        {
            myVisibility = false;
        }

        /// <summary>
        /// Toggles the myVisibility of the object. Once triggered, the attribute is applied automatically on drawing.
        /// </summary>
        public void ToggleVisibility()
        {
            myVisibility = !myVisibility;
        }

        /// <summary>
        /// Sets the normal size for the line's width.
        /// </summary>
        public void SetAsDefault()
        {
            myWidth = DEFAULT_SIZE;
        }

        /// <summary>
        /// Sets the highlighted (increased) size for the line's width.
        /// </summary>
        public void SetAsHighlight()
        {
            myWidth = BIG_SIZE;
        }

        /// <summary>
        /// Toggles the switch between normal draw and highlighted draw. When highlighted, all lines are wider.
        /// </summary>
        public void ToggleWidth()
        {
            if (myWidth == DEFAULT_SIZE)
            {
                myWidth = BIG_SIZE;
            }
            else
            {
                myWidth = DEFAULT_SIZE;
            }
        }

        /// <summary>
        /// Disco mode! Changes randomly the colors on the object.
        /// </summary>
        public void DiscoMode()
        {
            myColor = localR.RandomColor();
        }

        
    }
}
