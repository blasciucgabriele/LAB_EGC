﻿using OpenTK;
using OpenTK.Graphics;
using OpenTK.Graphics.OpenGL;
using OpenTK.Input;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Threading.Tasks;
using System.Timers;

namespace Laborator_EGC
{
    /// <summary>
    /// The graphic window. Contains the canvas (viewport to be draw).
    /// </summary>
    class Window3D : GameWindow
    {
       // private bool showCube = true; LABORATOR2
        private KeyboardState previousKeyboard;
        private MouseState previousMouse;
        private readonly Randomizer rando;
        private readonly Axes ax;
        private readonly Triangle3D t;
        private readonly List<Line3D> lofl;
        private readonly List<Point3D> pnt;
        private readonly List<Triangle3D> tr;
        private readonly List<Quads3D> sq;
        private readonly Cube3D cube;
        private readonly Grid g;
        private readonly Camera3DIsometric cam;
        Timer timer = new Timer();



        // DEFAULTS
        private Color DEFAULT_BKG_COLOR = Color.CornflowerBlue;

        /// <summary>
        /// Parametrised constructor. Invokes the anti-aliasing engine. All inits are placed here, for convenience.
        /// </summary>
        public Window3D() : base(800, 600, new GraphicsMode(32, 24, 0, 8))
        {
            VSync = VSyncMode.On;

            // inits
            rando = new Randomizer();
            cam = new Camera3DIsometric();
            ax = new Axes();
            t = new Triangle3D();
            g = new Grid();
           // lofl = Line3D.citire_fisier();
           // tr = Triangle3D.citire_fisier();
           // pnt = Point3D.citire_fisier();
           /// sq = Quads3D.citire_fisier();
            cube = new Cube3D();
        
            DisplayHelp();
        }

        /// <summary>
        /// OnLoad() method. Part of the control loop of the OpenTK API. Executed only once.
        /// </summary>
        /// <param name="e">event parameters that triggered the method;</param>
        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);
            GL.Enable(EnableCap.DepthTest);
            GL.Enable(EnableCap.Blend);
            GL.DepthFunc(DepthFunction.Less);
            GL.Hint(HintTarget.PolygonSmoothHint, HintMode.Nicest);
            
            
        }
        

        /// <summary>
        /// OnResize() method. Part of the control loop of the OpenTK API. Executed at least once (after OnLoad()).
        /// </summary>
        /// <param name="e">event parameters that triggered the method;</param>
        protected override void OnResize(EventArgs e)
        {
            base.OnResize(e);

            // set background
            GL.ClearColor(DEFAULT_BKG_COLOR);

            // set viewport
            GL.Viewport(0, 0, this.Width, this.Height);

            // set perspective
            Matrix4 perspectiva = Matrix4.CreatePerspectiveFieldOfView(MathHelper.PiOver4, (float)this.Width / (float)this.Height, 1, 250);
            GL.MatrixMode(MatrixMode.Projection);
            GL.LoadMatrix(ref perspectiva);

            // set the eye
            /*Matrix4 eye = Matrix4.LookAt(75, 75, 75, 0, 0, 0, 0, 1, 0);
            GL.MatrixMode(MatrixMode.Modelview);
            GL.LoadMatrix(ref eye);*/
            cam.SetCamera();
        }
       
        /// <summary>
        /// OnUpdateFrame() method. Part of the control loop of the OpenTK API. Executed periodically, with a frequency determined when launching
        /// the graphics window (<see cref="GameWindow.Run(double, double)"/>). In this case should be 30.00 (if unmodified).
        ///
        /// All logic should reside here!
        /// </summary>
        /// <param name="e">event parameters that triggered the method;</param>
        protected override void OnUpdateFrame(FrameEventArgs e)
        {
            base.OnUpdateFrame(e);

            
          
            // LOGIC CODE
            KeyboardState currentKeyboard = Keyboard.GetState();
            MouseState currentMouse = Mouse.GetState();
            
            

            ///////////////////////////////////////////LABORATOR 2//////////////////////////////////////////////////////////////////
            /*if (currentKeyboard[Key.Left] && !previousKeyboard[Key.Left]) {
                // Ascundere comandată, prin apăsarea unei taste - cu verificare de remanență! Timpul de reacțieuman << calculator.
                showCube = true;
            }
            if(currentKeyboard[Key.Right] && !previousKeyboard[Key.Right])
            {
                showCube = false;
            }
            

            if (currentMouse[MouseButton.Left] && !previousMouse[MouseButton.Left]) {
                    showCube = true;
            }
            if (currentMouse[MouseButton.Right] && !previousMouse[MouseButton.Left])
            {
                showCube = false;
            }*/
            if (currentKeyboard[Key.W])//LABORATOR 5
            {
                cam.MoveForward();
            }
            if (currentKeyboard[Key.S])//LABORATOR 5
            {
                cam.MoveBackward();
            }
            if (currentKeyboard[Key.A])//LABORATOR 5
            {
                cam.MoveLeft();
            }
            if (currentKeyboard[Key.D])//LABORATOR 5
            {
                cam.MoveRight();
            }
            if (currentKeyboard[Key.Q])//LABORATOR 5
            {
                cam.MoveUp();
            }
            if (currentKeyboard[Key.E])//LABORATOR 5
            {
                cam.MoveDown();
            }

            if (currentKeyboard[Key.O])//LABORATOR 5
            {
                cam.Departe();
            }
            if (currentKeyboard[Key.P])//LABORATOR 5
            {
                cam.Aproape();
            }

            if (currentKeyboard[Key.Up])//LABORATOR 5
            {
                cube.Move_y(2);
            }
            if (currentKeyboard[Key.Down])//LABORATOR 5
            {
                cube.Move_y(-2);
            }
            if (currentKeyboard[Key.Left])//LABORATOR 5
            {
                cube.Move_x(2);
            }
            if (currentKeyboard[Key.Right])//LABORATOR 5
            {
                cube.Move_x(-2);
            }
            if (currentKeyboard[Key.U])//LABORATOR 5
            {
                cube.Move_z(2);
            }
            if (currentKeyboard[Key.I]) //LABORATOR 5
            {
                cube.Move_z(-2);
            }

            if (currentKeyboard[Key.J]) //LABORATOR 5
            {
                cube.Gravity();
            }
            

            if (currentMouse[MouseButton.Left] && !previousMouse[MouseButton.Left])
            {
                cube.DiscoMode();
                /* foreach(Triangle3D t in tr)
                 {
                     t.DiscoMode();
                 }
                 foreach (Line3D l in lofl)
                 {
                     l.DiscoMode();
                 }
                 foreach (Point3D p in pnt)
                 {
                     p.DiscoMode();
                 }
                 foreach (Quads3D q in sq)
                 {
                     q.DiscoMode();
                 }*/
                t.DiscoMode();
               // cube.DiscoMode();
                //sq.Add(new Quads3D(rando));

            }

            if (currentKeyboard[Key.Escape])
            {
                Exit();
            }

           /* if (currentKeyboard[Key.H] && !previousKeyboard[Key.H])
            {
                DisplayHelp();
            }

            if (currentKeyboard[Key.R] && !previousKeyboard[Key.R])
            {
                GL.ClearColor(DEFAULT_BKG_COLOR);
                ax.Show();
                foreach (Quads3D line in sq)
                {
                    line.Hide();
                    
                }
            }

            if (currentKeyboard[Key.K] && !previousKeyboard[Key.K])
            {
                ax.ToggleVisibility();
            }

            if (currentKeyboard[Key.B] && !previousKeyboard[Key.B])
            {
                GL.ClearColor(rando.RandomColor());
               
            }*/

          /*  if (currentKeyboard[Key.X] && !previousKeyboard[Key.X]) //LABORATOR3
            {
                foreach (Quads3D line in sq)
                {
                    line.DiscoMode();
                }

                t.Change(-5);
             
               
            }*/
            if (currentKeyboard[Key.F] && !previousKeyboard[Key.F])
            {
                t.schimba_culoare(5);
                cube.schimba_culoare(5);
            }
            if (currentKeyboard[Key.G] && !previousKeyboard[Key.G])
            {
                t.schimba_culoare(-5);
                cube.schimba_culoare(-5);
            }

            /*  if (currentKeyboard[Key.V] && !previousKeyboard[Key.V])
              {
                  foreach (Quads3D line in sq)
                  {
                      line.ToggleVisibility();
                  }
              }*/
           /* if (currentKeyboard[Key.Z] && !previousKeyboard[Key.Z])
            {
                cube.ManualMoveMe(true, false, false, false, false, false);
            }
            if (currentKeyboard[Key.X] && !previousKeyboard[Key.X])
            {
                cube.ManualMoveMe(false, true, false, false, false, false);
            }
            if (currentKeyboard[Key.C] && !previousKeyboard[Key.C])
            {
                cube.ManualMoveMe(false, false, true, false, false, false);
            }
            if (currentKeyboard[Key.V] && !previousKeyboard[Key.V])
            {
                cube.ManualMoveMe(false, false, false, true, false, false);
            }
            if (currentKeyboard[Key.B] && !previousKeyboard[Key.B])
            {
                cube.ManualMoveMe(false, false, false, false, true, false);
            }
            if (currentKeyboard[Key.N] && !previousKeyboard[Key.N])
            {
                cube.ManualMoveMe(false, false, false, false, false, true);
            }*/

            previousKeyboard = currentKeyboard;
            previousMouse = currentMouse;
            // END logic code
        }

        /// <summary>
        /// OnRenderFrame() method. Part of the control loop of the OpenTK API. Executed periodically, with a frequency determined when launching
        /// the graphics window (<see cref="GameWindow.Run(double, double)"/>). In this case should be 0.00 (if unmodified) - the rendering is triggered
        /// only when the scene is modified.
        ///
        /// All render calls should reside here!
        /// </summary>
        /// <param name="e">event parameters that triggered the method;</param>
        protected override void OnRenderFrame(FrameEventArgs e)
        {
            base.OnRenderFrame(e);

            GL.Clear(ClearBufferMask.ColorBufferBit);
            GL.Clear(ClearBufferMask.DepthBufferBit);

            // RENDER CODE
            ax.Draw();
            /* if (showCube == true) //LABORATOR2
             {
                 DrawCube();
             }*/


            /*foreach (Triangle3D line in tr)
        {
            line.Draw();
        }
        foreach (Line3D line in lofl)
        {
            line.Draw();
        }
        foreach (Point3D p in pnt)
        {
            p.Draw();
        }
        foreach (Quads3D q in sq)
        {
            q.Draw();
        }*/
            cube.Draw();
            g.Draw();
            
            ///t.Draw();
            // END render code

            SwapBuffers();
        }
      /*  private void DrawCube() //LABORATOR2
        {
            GL.Begin(PrimitiveType.Quads);

            GL.Color3(Color.Silver);
            GL.Vertex3(-1.0f, -1.0f, -1.0f);
            GL.Vertex3(-1.0f, 1.0f, -1.0f);
            GL.Vertex3(1.0f, 1.0f, -1.0f);
            GL.Vertex3(1.0f, -1.0f, -1.0f);

            GL.Color3(Color.Honeydew);
            GL.Vertex3(-1.0f, -1.0f, -1.0f);
            GL.Vertex3(1.0f, -1.0f, -1.0f);
            GL.Vertex3(1.0f, -1.0f, 1.0f);
            GL.Vertex3(-1.0f, -1.0f, 1.0f);

            GL.Color3(Color.Moccasin);

            GL.Vertex3(-1.0f, -1.0f, -1.0f);
            GL.Vertex3(-1.0f, -1.0f, 1.0f);
            GL.Vertex3(-1.0f, 1.0f, 1.0f);
            GL.Vertex3(-1.0f, 1.0f, -1.0f);

            GL.Color3(Color.IndianRed);
            GL.Vertex3(-1.0f, -1.0f, 1.0f);
            GL.Vertex3(1.0f, -1.0f, 1.0f);
            GL.Vertex3(1.0f, 1.0f, 1.0f);
            GL.Vertex3(-1.0f, 1.0f, 1.0f);

            GL.Color3(Color.PaleVioletRed);
            GL.Vertex3(-1.0f, 1.0f, -1.0f);
            GL.Vertex3(-1.0f, 1.0f, 1.0f);
            GL.Vertex3(1.0f, 1.0f, 1.0f);
            GL.Vertex3(1.0f, 1.0f, -1.0f);

            GL.Color3(Color.ForestGreen);
            GL.Vertex3(1.0f, -1.0f, -1.0f);
            GL.Vertex3(1.0f, 1.0f, -1.0f);
            GL.Vertex3(1.0f, 1.0f, 1.0f);
            GL.Vertex3(1.0f, -1.0f, 1.0f);

            GL.End();
        }*/

        /// <summary>
        /// Internal method, used to dump the menu on the console window (text mode!)...
        /// </summary>
        private void DisplayHelp()
        {
            Console.WriteLine("\n      MENIU");
            Console.WriteLine(" (H) - meniul");
            Console.WriteLine(" (click stanga) - schimba culoare cub");
            Console.WriteLine(" (sageata stanga) -  miscare cub inapoi");
            Console.WriteLine(" (sageata dreapta) - miscare cub inainte");
            Console.WriteLine(" (U) -  miscare cub stanga");
            Console.WriteLine(" (I) - miscare cub dreapta");
            Console.WriteLine(" (sageata sus) - miscare cub sus");
            Console.WriteLine(" (sageata jos) - miscare cub jos");
            Console.WriteLine(" (F) - transparenta + cub");
            Console.WriteLine(" (G) - transparenta - cub");
            Console.WriteLine(" (P) - camera apropriata");
            Console.WriteLine(" (O) - camera indepartata");
            Console.WriteLine(" (J) - cub in cadere libera");

            Console.WriteLine("\n\n FOLOSITI CLIC DE MOUSE PENTRU A GENERA NOI LINII!");
        }

    }
}
