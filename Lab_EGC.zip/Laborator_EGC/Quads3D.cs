﻿using OpenTK;
using OpenTK.Graphics.OpenGL;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;

namespace Laborator_EGC
{
    class Quads3D
    {
        private Vector3 pointA;
        private Vector3 pointB;
        private Vector3 pointC;
        private Vector3 pointD;
        private bool myVisibility;
        private Color myColor;
        private Randomizer localR;

        public Quads3D(Vector3 A, Vector3 B, Vector3 C, Vector3 D)
        {
            localR = new Randomizer();
            pointA = A;
            pointB = B;
            pointC = C;
            pointD = D;
            myColor = localR.RandomColor();
            myVisibility = true;
        }
        public Quads3D(Randomizer _r)
        {
            localR = _r;
            pointA = localR.Random3DPoint();
            pointB = localR.Random3DPoint();
            pointC = localR.Random3DPoint();
            pointD = localR.Random3DPoint();
            myColor = localR.RandomColor();
            myVisibility = true;
        }

        public static List<Quads3D> citire_fisier()
        {
            List<Quads3D> quaduri = new List<Quads3D>();
            Vector3[] vect;
            string fisier = "C:\\Users\\blasc\\Desktop\\Full_obj_deployment_OpenTK\\Coordinates.txt";
            try
            {
                using (StreamReader s = new StreamReader(fisier))
                {
                    string line;

                    while ((line = s.ReadLine()) != null)
                    {
                        string[] st = line.Split(' ');
                        vect = new Vector3[st.Length];
                        for (int i = 0; i < st.Length; i++)
                        {
                            string[] pt = st[i].Split(',');
                            Vector3 pnt = new Vector3(Int32.Parse(pt[0]), Int32.Parse(pt[1]), Int32.Parse(pt[2]));
                            vect[i] = pnt;
                        }
                        if (st.Length == 4)
                        {
                            Quads3D q = new Quads3D(vect[0], vect[1], vect[2], vect[3]);
                            quaduri.Add(q);
                        }
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            return quaduri;
        }

        public void Draw()
        {
            if (myVisibility)
            {
                GL.Begin(PrimitiveType.Quads);
                GL.Color3(myColor);
                GL.Vertex3(pointA);
                GL.Vertex3(pointB);
                GL.Vertex3(pointC);
                GL.Vertex3(pointD);
                GL.End();
            }
        }

        public void Show()
        {
            myVisibility = true;
        }

        public void Hide()
        {
            myVisibility = false;
        }

        public void ToggleVisibility()
        {
            myVisibility = !myVisibility;
        }

        public void DiscoMode()
        {
            myColor = localR.RandomColor();
        }

    }
}
