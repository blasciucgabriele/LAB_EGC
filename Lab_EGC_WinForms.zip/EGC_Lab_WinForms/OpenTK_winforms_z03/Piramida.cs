﻿using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Windows.Forms;
using OpenTK;
using OpenTK.Graphics.OpenGL;


namespace OpenTK_winforms_z02
{
    public class Piramida
    {
        bool visibil;
        public Piramida()
        {
            visibil = true;
        }
        public void Draw_Tex1()
        {
            if(visibil)
            {
                GL.Begin(PrimitiveType.Quads);
                GL.TexCoord2(0.0, 1.0);
                GL.Vertex3(-20, 0, -20);
                GL.TexCoord2(1.0, 1.0);
                GL.Vertex3(20, 0, -20);
                GL.TexCoord2(1.0, 0.0);
                GL.Vertex3(20, 0, 20);
                GL.TexCoord2(0.0, 0.0);
                GL.Vertex3(-20, 0, 20);
                GL.End();

                GL.Begin(PrimitiveType.Triangles);
                GL.TexCoord2(0.0, 1.0);
                GL.Vertex3(0, 40, 0);
                GL.TexCoord2(1.0, 1.0);
                GL.Vertex3(-20, 0, -20);
                GL.TexCoord2(1.0, 0.0);
                GL.Vertex3(20, -0, -20);

                GL.TexCoord2(0.0, 1.0);
                GL.Vertex3(0, 40, 0);
                GL.TexCoord2(1.0, 1.0);
                GL.Vertex3(-20, 0, 20);
                GL.TexCoord2(1.0, 0.0);
                GL.Vertex3(-20, 0, -20);

                GL.TexCoord2(0.0, 1.0);
                GL.Vertex3(0, 40, 0);
                GL.TexCoord2(1.0, 1.0);
                GL.Vertex3(20, 0, 20);
                GL.TexCoord2(1.0, 0.0);
                GL.Vertex3(-20, 0, 20);

                GL.TexCoord2(0.0, 1.0);
                GL.Vertex3(0, 40, 0);
                GL.TexCoord2(1.0, 1.0);
                GL.Vertex3(20, 0, 20);
                GL.TexCoord2(1.0, 0.0);
                GL.Vertex3(20, 0, -20);

                GL.End();
            }
        }
        public void Draw_Tex2()
        {
            if (visibil)
            {
                GL.Begin(PrimitiveType.Quads);
                GL.TexCoord2(0.0, 0.5);
                GL.Vertex3(-20, 0, -20);
                GL.TexCoord2(0.5, 0.5);
                GL.Vertex3(20, 0, -20);
                GL.TexCoord2(0.5, 0.0);
                GL.Vertex3(20, 0, 20);
                GL.TexCoord2(0.0, 0.0);
                GL.Vertex3(-20, 0, 20);
                GL.End();

                GL.Begin(PrimitiveType.Triangles);
                GL.TexCoord2(0.0, 0.5);
                GL.Vertex3(0, 40, 0);
                GL.TexCoord2(0.5, 0.5);
                GL.Vertex3(-20, 0, -20);
                GL.TexCoord2(0.5, 0.0);
                GL.Vertex3(20, 0, -20);

                GL.TexCoord2(0.0, 0.5);
                GL.Vertex3(0, 40, 0);
                GL.TexCoord2(0.5, 0.5);
                GL.Vertex3(-20, 0, 20);
                GL.TexCoord2(0.5, 0.0);
                GL.Vertex3(-20, 0, -20);

                GL.TexCoord2(0.0, 0.5);
                GL.Vertex3(0, 40, 0);
                GL.TexCoord2(0.5, 0.5);
                GL.Vertex3(20, 0, 20);
                GL.TexCoord2(0.5, 0.0);
                GL.Vertex3(-20, 0, 20);

                GL.TexCoord2(0.0, 0.5);
                GL.Vertex3(0, 40, 0);
                GL.TexCoord2(0.5, 0.5);
                GL.Vertex3(20, 0, 20);
                GL.TexCoord2(0.5, 0.0);
                GL.Vertex3(20, 0, -20);

                GL.End();
            }
        }

        public void Hide()
        {
            visibil = false;
        }
    }
}
